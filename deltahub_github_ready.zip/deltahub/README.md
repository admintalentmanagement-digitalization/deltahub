# DeltaHub

**Intelligent Data Reconciliation Platform**

DeltaHub is a lightweight browser-based data reconciliation tool designed to reduce manual lookup, spreadsheet comparison, and repetitive update work.

## Core Features

- Create or open project
- Project type: Succession, PAT, Talent Mapping, Custom
- Upload Working Master Excel
- Upload Reference Excel per update step
- Detect key column such as NIK / Employee ID / Personnel Number
- Select columns to update
- Preview delta before applying changes
- Apply changes to Working Master
- Download final Excel
- Download changelog Excel
- Save and reopen project JSON
- Access control with Admin / Editor / Viewer roles
- Optional DeepSeek AI buttons:
  - AI Suggest Mapping
  - AI Recommend Update
  - AI Summary

## Token-Safe AI Design

Default processing uses zero DeepSeek tokens. AI is only called when a user manually clicks an AI button. The app sends column names, selected columns, and summary statistics only; it does not send full employee rows.

## GitHub Pages Setup

1. Create a GitHub repository named `deltahub`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open repository Settings.
4. Go to Pages.
5. Select `Deploy from branch`.
6. Choose branch `main` and folder `/root`.
7. The app URL will be:

```text
https://<github-username>.github.io/deltahub/
```

## Product Name

DeltaHub  
Intelligent Data Reconciliation Platform
